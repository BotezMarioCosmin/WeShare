﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices.ComTypes;
using System.Text;

namespace WeShare_Server
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Indirizzo IP e porta su cui il server ascolterà
            IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
            int port = 8888;

            // Creazione del listener TCP
            TcpListener server = new TcpListener(ipAddress, port);

            // Avvio del server
            server.Start();
            Console.WriteLine("Server avviato...");

            // Verifica e crea la cartella "Files" se non esiste
            string filesDirectory = Path.Combine(Directory.GetCurrentDirectory(), "Files");
            if (!Directory.Exists(filesDirectory))
            {
                Directory.CreateDirectory(filesDirectory);
            }

            while (true)
            {
                // Accetta una connessione dal client
                TcpClient client = server.AcceptTcpClient();
                string clientId = GenerateClientId();
                string connectedClientInfo = $"Client connesso. ID: {clientId}";

                // Stampa l'informazione del client connesso
                Console.WriteLine(connectedClientInfo);

                NetworkStream stream = client.GetStream();
                StreamWriter writer = new StreamWriter(stream);
                // Invia l'ID del client al client
                writer.WriteLine(clientId);
                writer.Flush();


                // Gestisci la richiesta del client in un thread separato
                System.Threading.Thread t = new System.Threading.Thread(() => HandleClient(client, clientId));
                t.Start();
            }
        }

        static void HandleClient(TcpClient client, string clientId)
        {
            NetworkStream stream = client.GetStream();
            StreamReader reader = new StreamReader(stream);
            StreamWriter writer = new StreamWriter(stream);

            try
            {

                while (true)
                {
                    // Ricevi il comando dal client
                    string command = reader.ReadLine();


                    if (command == "UPLOAD")
                    {
                        Console.WriteLine($"Richiesta dal client {clientId}: {command}");
                        // Ricevi il nome del file dal client
                        string fileName = reader.ReadLine();
                        Console.WriteLine("Ricezione file: " + fileName);

                        // Percorso completo del file sul server
                        string filePath = Path.Combine(Directory.GetCurrentDirectory(), "Files", fileName);

                        // Ricevi il contenuto del file dal client
                        byte[] buffer = new byte[client.ReceiveBufferSize];
                        int bytesRead = stream.Read(buffer, 0, buffer.Length);

                        // Salva il file sul disco
                        FileStream fileStream = File.Create(filePath);
                        fileStream.Write(buffer, 0, bytesRead);
                        fileStream.Close();

                        Console.WriteLine("File ricevuto e salvato: " + filePath);
                        writer.Flush();
                        // Invia un segnale al client per confermare il ricevimento del file
                        //writer.WriteLine("UPLOAD_OK");
                    }
                    else if (command == "REQUEST")
                    {
                        Console.WriteLine($"Richiesta dal client {clientId}: {command}");
                        // Ricevi il nome del file richiesto dal client
                        string requestedFileName = reader.ReadLine();
                        Console.WriteLine("Richiesta di file: " + requestedFileName);

                        // Percorso completo del file sul server
                        string filePath = Path.Combine(Directory.GetCurrentDirectory(), "Files", requestedFileName);

                        // Verifica se il file richiesto esiste
                        if (!File.Exists(filePath))
                        {
                            Console.WriteLine("Il file richiesto non esiste.");
                            //writer.WriteLine("FILE_NOT_FOUND");
                            writer.Flush();
                            continue;
                        }

                        // Leggi il contenuto del file
                        byte[] fileBytes = File.ReadAllBytes(filePath);

                        // Invia il contenuto del file al client
                        stream.Write(fileBytes, 0, fileBytes.Length);
                        stream.Write(new byte[] { 0 }, 0, 1); // Invia un segnale di fine file
                        Console.WriteLine("File inviato: " + requestedFileName);
                    }
                    else if (command == "CLOSE")
                    {
                        Console.WriteLine($"Richiesta dal client {clientId}: {command}");
                        // Chiudi la connessione
                        client.Close();
                        Console.WriteLine("Connessione chiusa con il client.");
                        break;
                    }
                    else if (command == "LIST")
                    {
                        Console.WriteLine($"Richiesta dal client {clientId}: {command}");
                        // Ottieni l'elenco dei file nella cartella "Files"
                        string filesDirectory = Path.Combine(Directory.GetCurrentDirectory(), "Files");
                        string[] fileNames = GetFiles(filesDirectory);

                        // Invia l'elenco dei file al client
                        writer.WriteLine(string.Join(";", fileNames)); // Modifica ";" per concatenare i nomi dei file
                        writer.Flush();
                    }
                    else if (command == "DELETE")
                    {
                        Console.WriteLine($"Richiesta dal client {clientId}: {command}");
                        // Ricevi il nome del file da eliminare dal client
                        string fileNameToDelete = reader.ReadLine();
                        Console.WriteLine("Richiesta di eliminazione del file: " + fileNameToDelete);

                        // Percorso completo del file da eliminare
                        string filePathToDelete = Path.Combine(Directory.GetCurrentDirectory(), "Files", fileNameToDelete);

                        // Verifica se il file esiste prima di eliminarlo
                        if (File.Exists(filePathToDelete))
                        {
                            File.Delete(filePathToDelete);
                            Console.WriteLine("File eliminato: " + fileNameToDelete);
                            writer.WriteLine("DELETE_OK"); // Invia conferma al client
                        }
                        else
                        {
                            Console.WriteLine("Il file richiesto per l'eliminazione non esiste.");
                            writer.WriteLine("FILE_NOT_FOUND"); // Invia notifica al client se il file non è stato trovato
                        }
                        writer.Flush();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore: " + ex.Message);
            }
        }

        public static string[] GetFiles(string directoryPath)
        {
            try
            {
                // Verifica se la directory esiste
                if (!Directory.Exists(directoryPath))
                {
                    throw new DirectoryNotFoundException($"La directory '{directoryPath}' non esiste.");
                }

                // Ottieni tutti i nomi dei file nella directory
                string[] fileNames = Directory.GetFiles(directoryPath)
                                               .Select(Path.GetFileName)
                                               .ToArray();

                return fileNames;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Errore durante il recupero dei file dalla directory '{directoryPath}': {ex.Message}");
                return new string[0]; // Restituisce un array vuoto in caso di errore
            }
        }

        public static string GenerateClientId()
        {
            // Genera un ID del client casuale composto da 4 caratteri (cifre e lettere maiuscole)
            Random random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, 4)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}
