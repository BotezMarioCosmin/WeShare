﻿using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace WeShare_Client
{
    public partial class Form1 : Form
    {
        private TcpClient client;
        private NetworkStream stream;
        private string clientId;

        public Form1()
        {
            InitializeComponent();

            txtClient.Text = "N/D"; // Imposta un valore predefinito per l'ID del client

            string filesDirectory = Path.Combine(Directory.GetCurrentDirectory(), "Files");
            if (!Directory.Exists(filesDirectory))
            {
                Directory.CreateDirectory(filesDirectory);
            }
            // Chiamare il metodo di connessione al server all'avvio dell'applicazione
            txtConnessione.Text = "Non connesso";
            txtConnessione.ForeColor = Color.FromArgb(255, 40, 40);

            listBox1.BackColor = Color.FromArgb(17, 63, 80);
            listBox1.ForeColor = Color.FromArgb(50, 180, 130);
            listBox1.Font = new Font("Times New Roman", 10, FontStyle.Regular);
            listBox1.ItemHeight = 30; // Imposta l'altezza degli elementi a 30 pixel
        }



        private void btnSelezionaFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            // Imposta le proprietà del dialogo
            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                // Ottieni il percorso completo del file selezionato
                string selectedFileName = openFileDialog1.FileName;

                // Imposta il nome del file nella TextBox
                txtFileName.Text = selectedFileName;
            }
        }

        private void btnInviaFile_Click(object sender, EventArgs e)
        {
            try
            {
                if (client == null || !client.Connected)
                {
                    MessageBox.Show("Connessione al server non disponibile.", "Errore");
                    return;
                }

                string fileName = txtFileName.Text;

                if (!File.Exists(fileName))
                {
                    MessageBox.Show("Il file selezionato non esiste.", "Avviso");
                    return;
                }

                // Invia il comando al server
                StreamWriter writer = new StreamWriter(stream);
                writer.WriteLine("UPLOAD");
                writer.Flush();

                // Invia il nome del file al server
                writer.WriteLine(Path.GetFileName(fileName));
                writer.Flush();

                MessageBox.Show("File inviato con successo.", "Avviso");

                // Invia il contenuto del file al server
                byte[] fileBytes = File.ReadAllBytes(fileName);
                stream.Write(fileBytes, 0, fileBytes.Length);

                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Errore");
            }
            txtFileName.Text = null;

            listBox1.Items.Clear();
            foreach (string f in GetFileList())
            {
                listBox1.Items.Add(f);
            }
        }


        private void btnRichiediFile_Click(object sender, EventArgs e)
        {
            try
            {
                if (client == null || !client.Connected)
                {
                    MessageBox.Show("Connessione al server non disponibile.","Errore");
                    return;
                }

                string requestedFileName = txtRequestedFileName.Text;

                // Invia il comando al server
                StreamWriter writer = new StreamWriter(stream);
                writer.WriteLine("REQUEST");
                writer.Flush();

                // Invia il nome del file richiesto al server
                writer.WriteLine(requestedFileName);
                writer.Flush();

                // Ricevi la risposta dal server
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    byte[] buffer = new byte[client.ReceiveBufferSize];
                    int bytesRead;
                    bool nullByteFound = false;
                    while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        for (int i = 0; i < bytesRead; i++)
                        {
                            // Verifica se è stato ricevuto il segnale di fine file
                            if (buffer[i] == 0)
                            {
                                nullByteFound = true;
                                break;
                            }
                        }

                        if (nullByteFound)
                        {
                            memoryStream.Write(buffer, 0, bytesRead - 1);
                            break;
                        }
                        else
                        {
                            memoryStream.Write(buffer, 0, bytesRead);
                        }
                    }

                    // Ottieni il contenuto del file dalla MemoryStream
                    byte[] fileBytes = memoryStream.ToArray();

                    if (fileBytes.Length == 0)
                    {
                        // Il file ricevuto è vuoto
                        MessageBox.Show("Il file ricevuto è vuoto.");
                        return;
                    }

                    // Salva il file ricevuto nella cartella "Files"
                    string filesDirectory = Path.Combine(Directory.GetCurrentDirectory(), "Files");
                    string filePath = Path.Combine(filesDirectory, requestedFileName);
                    File.WriteAllBytes(filePath, fileBytes);

                    // Visualizza un messaggio di conferma
                    MessageBox.Show("File ricevuto con successo. Salvato in: " + filePath);

                    // Apre il file ricevuto con l'applicazione predefinita
                    System.Diagnostics.Process.Start(filePath);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Errore");
            }
            txtRequestedFileName.Text = null;
        }

        private void ConnectToServer()
        {
            try
            {
                string serverIp = "127.0.0.1";
                int serverPort = 8888;

                // Connessione al server
                client = new TcpClient(serverIp, serverPort);
                stream = client.GetStream();

                MessageBox.Show("Connessione al server avvenuta con successo.");
                txtConnessione.Text = "Connesso";
                txtConnessione.ForeColor = Color.FromArgb(127, 221, 27);

                // Ricevi e visualizza l'ID del client dal server
                StreamReader reader = new StreamReader(stream);
                clientId = reader.ReadLine();
                txtClient.Text = clientId; // txtClientId è il nome della TextBox in cui visualizzeremo l'ID del client
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Errore nella connessione al server:", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtConnessione.Text = "Non connesso";
                txtConnessione.ForeColor = Color.FromArgb(255, 40, 40);
            }


        }

        private void btnDisconnetti_Click(object sender, EventArgs e)
        {
            try
            {
                if (client != null && client.Connected)
                {
                    // Invia il comando al server
                    StreamWriter writer = new StreamWriter(stream);
                    writer.WriteLine("CLOSE");
                    writer.Flush();

                    // Chiudi la connessione al server
                    client.Close();
                    stream.Close();
                    MessageBox.Show("Connessione al server interrotta correttamente.");
                    txtConnessione.Text = "Disconnesso";
                    txtConnessione.ForeColor = Color.FromArgb(255, 40, 40);

                    txtClient.Text = null;
                }
                else
                {
                    MessageBox.Show("Non sei connesso al server.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtConnessione.Text = "Non connesso";
                    txtConnessione.ForeColor = Color.FromArgb(255, 40, 40);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnConnetti_Click(object sender, EventArgs e)
        {
            ConnectToServer();

            listBox1.Items.Clear();
            foreach (string f in GetFileList())
            {
                listBox1.Items.Add(f);
            }
        }
        private string[] GetFileList()
        {
            try
            {
                // Verifica la connessione al server
                if (client == null || !client.Connected)
                {
                    MessageBox.Show("Connessione al server non disponibile.", "Errore");
                    return new string[0];
                }

                // Invia il comando al server
                StreamWriter writer = new StreamWriter(stream);
                writer.WriteLine("LIST");
                writer.Flush();

                // Leggi la risposta dal server
                StreamReader reader = new StreamReader(stream);
                string fileList = reader.ReadLine();

                // Suddivide l'elenco dei file per ";"
                string[] files = fileList.Split(';');

                return files;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Errore");
                return new string[0];
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Verifica se è selezionato un elemento nella ListBox
            if (listBox1.SelectedIndex != -1)
            {
                // Ottieni il testo dell'elemento selezionato nella ListBox
                string selectedItemText = listBox1.SelectedItem.ToString();

                // Imposta il testo della TextBox con il testo dell'elemento selezionato
                txtRequestedFileName.Text = selectedItemText;
            }
        }

        private void btnDeseleziona_Click(object sender, EventArgs e)
        {
            txtRequestedFileName.Text = null;
            listBox1.SelectedIndex = -1;
        }

        private void btnElimina_Click(object sender, EventArgs e)
        {
            try
            {
                if (client == null || !client.Connected)
                {
                    MessageBox.Show("Connessione al server non disponibile.", "Errore");
                    return;
                }

                string fileNameToDelete = txtRequestedFileName.Text;

                // Invia il comando al server
                StreamWriter writer = new StreamWriter(stream);
                writer.WriteLine("DELETE");
                writer.Flush();

                // Invia il nome del file da eliminare al server
                writer.WriteLine(fileNameToDelete);
                writer.Flush();

                // Leggi la risposta dal server
                StreamReader reader = new StreamReader(stream);
                string response = reader.ReadLine();

                if (response == "DELETE_OK")
                {
                    MessageBox.Show("File eliminato con successo.", "Avviso");
                }
                else if (response == "FILE_NOT_FOUND")
                {
                    MessageBox.Show("Il file specificato non esiste sul server.", "Avviso");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Errore");
            }

            listBox1.Items.Clear();
            foreach (string f in GetFileList())
            {
                listBox1.Items.Add(f);
            }
            txtRequestedFileName.Text = null;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            foreach (string f in GetFileList())
            {
                listBox1.Items.Add(f);
            }
        }
    }
}
