﻿namespace WeShare_Client
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.txtFileName = new System.Windows.Forms.TextBox();
            this.btnSelezionaFile = new System.Windows.Forms.Button();
            this.btnRichiediFile = new System.Windows.Forms.Button();
            this.txtRequestedFileName = new System.Windows.Forms.TextBox();
            this.btnDisconnetti = new System.Windows.Forms.Button();
            this.btnConnetti = new System.Windows.Forms.Button();
            this.txtConnessione = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.lblInvia = new System.Windows.Forms.Label();
            this.lblRichiesta = new System.Windows.Forms.Label();
            this.lblVisualizz = new System.Windows.Forms.Label();
            this.btnDeseleziona = new System.Windows.Forms.Button();
            this.btnElimina = new System.Windows.Forms.Button();
            this.btnDeseleziona2 = new System.Windows.Forms.Button();
            this.txtClient = new System.Windows.Forms.TextBox();
            this.lblClient = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(329, 410);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Invia";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnInviaFile_Click);
            // 
            // txtFileName
            // 
            this.txtFileName.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFileName.Location = new System.Drawing.Point(11, 382);
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.ReadOnly = true;
            this.txtFileName.Size = new System.Drawing.Size(393, 22);
            this.txtFileName.TabIndex = 1;
            // 
            // btnSelezionaFile
            // 
            this.btnSelezionaFile.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelezionaFile.Location = new System.Drawing.Point(11, 410);
            this.btnSelezionaFile.Name = "btnSelezionaFile";
            this.btnSelezionaFile.Size = new System.Drawing.Size(75, 23);
            this.btnSelezionaFile.TabIndex = 3;
            this.btnSelezionaFile.Text = "Seleziona";
            this.btnSelezionaFile.UseVisualStyleBackColor = true;
            this.btnSelezionaFile.Click += new System.EventHandler(this.btnSelezionaFile_Click);
            // 
            // btnRichiediFile
            // 
            this.btnRichiediFile.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRichiediFile.Location = new System.Drawing.Point(248, 309);
            this.btnRichiediFile.Name = "btnRichiediFile";
            this.btnRichiediFile.Size = new System.Drawing.Size(75, 23);
            this.btnRichiediFile.TabIndex = 4;
            this.btnRichiediFile.Text = "Richiedi";
            this.btnRichiediFile.UseVisualStyleBackColor = true;
            this.btnRichiediFile.Click += new System.EventHandler(this.btnRichiediFile_Click);
            // 
            // txtRequestedFileName
            // 
            this.txtRequestedFileName.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRequestedFileName.Location = new System.Drawing.Point(11, 281);
            this.txtRequestedFileName.Name = "txtRequestedFileName";
            this.txtRequestedFileName.Size = new System.Drawing.Size(393, 22);
            this.txtRequestedFileName.TabIndex = 5;
            // 
            // btnDisconnetti
            // 
            this.btnDisconnetti.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnDisconnetti.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisconnetti.Location = new System.Drawing.Point(278, 6);
            this.btnDisconnetti.Name = "btnDisconnetti";
            this.btnDisconnetti.Size = new System.Drawing.Size(127, 23);
            this.btnDisconnetti.TabIndex = 6;
            this.btnDisconnetti.Text = "Disconnetti";
            this.btnDisconnetti.UseVisualStyleBackColor = false;
            this.btnDisconnetti.Click += new System.EventHandler(this.btnDisconnetti_Click);
            // 
            // btnConnetti
            // 
            this.btnConnetti.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(180)))), ((int)(((byte)(130)))));
            this.btnConnetti.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConnetti.ForeColor = System.Drawing.Color.White;
            this.btnConnetti.Location = new System.Drawing.Point(145, 6);
            this.btnConnetti.Name = "btnConnetti";
            this.btnConnetti.Size = new System.Drawing.Size(127, 23);
            this.btnConnetti.TabIndex = 7;
            this.btnConnetti.Text = "Connetti";
            this.btnConnetti.UseVisualStyleBackColor = false;
            this.btnConnetti.Click += new System.EventHandler(this.btnConnetti_Click);
            // 
            // txtConnessione
            // 
            this.txtConnessione.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(83)))), ((int)(((byte)(102)))));
            this.txtConnessione.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConnessione.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.txtConnessione.Location = new System.Drawing.Point(12, 7);
            this.txtConnessione.Name = "txtConnessione";
            this.txtConnessione.ReadOnly = true;
            this.txtConnessione.Size = new System.Drawing.Size(127, 22);
            this.txtConnessione.TabIndex = 8;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(11, 88);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(393, 147);
            this.listBox1.TabIndex = 10;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // lblInvia
            // 
            this.lblInvia.AutoSize = true;
            this.lblInvia.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(180)))), ((int)(((byte)(130)))));
            this.lblInvia.Location = new System.Drawing.Point(6, 351);
            this.lblInvia.Name = "lblInvia";
            this.lblInvia.Size = new System.Drawing.Size(111, 28);
            this.lblInvia.TabIndex = 11;
            this.lblInvia.Text = "Invio File";
            // 
            // lblRichiesta
            // 
            this.lblRichiesta.AutoSize = true;
            this.lblRichiesta.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRichiesta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(180)))), ((int)(((byte)(130)))));
            this.lblRichiesta.Location = new System.Drawing.Point(6, 250);
            this.lblRichiesta.Name = "lblRichiesta";
            this.lblRichiesta.Size = new System.Drawing.Size(154, 28);
            this.lblRichiesta.TabIndex = 12;
            this.lblRichiesta.Text = "Seleziona File";
            // 
            // lblVisualizz
            // 
            this.lblVisualizz.AutoSize = true;
            this.lblVisualizz.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVisualizz.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(180)))), ((int)(((byte)(130)))));
            this.lblVisualizz.Location = new System.Drawing.Point(11, 57);
            this.lblVisualizz.Name = "lblVisualizz";
            this.lblVisualizz.Size = new System.Drawing.Size(280, 28);
            this.lblVisualizz.TabIndex = 13;
            this.lblVisualizz.Text = "Visualizzazione File Server";
            // 
            // btnDeseleziona
            // 
            this.btnDeseleziona.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeseleziona.Location = new System.Drawing.Point(11, 309);
            this.btnDeseleziona.Name = "btnDeseleziona";
            this.btnDeseleziona.Size = new System.Drawing.Size(75, 23);
            this.btnDeseleziona.TabIndex = 14;
            this.btnDeseleziona.Text = "Deseleziona";
            this.btnDeseleziona.UseVisualStyleBackColor = true;
            this.btnDeseleziona.Click += new System.EventHandler(this.btnDeseleziona_Click);
            // 
            // btnElimina
            // 
            this.btnElimina.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnElimina.Location = new System.Drawing.Point(329, 309);
            this.btnElimina.Name = "btnElimina";
            this.btnElimina.Size = new System.Drawing.Size(75, 23);
            this.btnElimina.TabIndex = 15;
            this.btnElimina.Text = "Elimina";
            this.btnElimina.UseVisualStyleBackColor = true;
            this.btnElimina.Click += new System.EventHandler(this.btnElimina_Click);
            // 
            // btnDeseleziona2
            // 
            this.btnDeseleziona2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeseleziona2.Location = new System.Drawing.Point(92, 410);
            this.btnDeseleziona2.Name = "btnDeseleziona2";
            this.btnDeseleziona2.Size = new System.Drawing.Size(75, 23);
            this.btnDeseleziona2.TabIndex = 16;
            this.btnDeseleziona2.Text = "Deseleziona";
            this.btnDeseleziona2.UseVisualStyleBackColor = true;
            // 
            // txtClient
            // 
            this.txtClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(83)))), ((int)(((byte)(102)))));
            this.txtClient.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtClient.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.txtClient.Location = new System.Drawing.Point(349, 32);
            this.txtClient.Margin = new System.Windows.Forms.Padding(0);
            this.txtClient.Name = "txtClient";
            this.txtClient.ReadOnly = true;
            this.txtClient.Size = new System.Drawing.Size(56, 22);
            this.txtClient.TabIndex = 17;
            // 
            // lblClient
            // 
            this.lblClient.AutoSize = true;
            this.lblClient.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClient.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(180)))), ((int)(((byte)(130)))));
            this.lblClient.Location = new System.Drawing.Point(278, 32);
            this.lblClient.Name = "lblClient";
            this.lblClient.Size = new System.Drawing.Size(65, 22);
            this.lblClient.TabIndex = 18;
            this.lblClient.Text = "Client:";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.Location = new System.Drawing.Point(11, 35);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 23);
            this.btnRefresh.TabIndex = 19;
            this.btnRefresh.Text = "Aggiorna";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(83)))), ((int)(((byte)(102)))));
            this.ClientSize = new System.Drawing.Size(415, 444);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.lblClient);
            this.Controls.Add(this.txtClient);
            this.Controls.Add(this.btnDeseleziona2);
            this.Controls.Add(this.btnElimina);
            this.Controls.Add(this.btnDeseleziona);
            this.Controls.Add(this.lblVisualizz);
            this.Controls.Add(this.lblRichiesta);
            this.Controls.Add(this.lblInvia);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.txtConnessione);
            this.Controls.Add(this.btnConnetti);
            this.Controls.Add(this.btnDisconnetti);
            this.Controls.Add(this.txtRequestedFileName);
            this.Controls.Add(this.btnRichiediFile);
            this.Controls.Add(this.btnSelezionaFile);
            this.Controls.Add(this.txtFileName);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "WeShare";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtFileName;
        private System.Windows.Forms.Button btnSelezionaFile;
        private System.Windows.Forms.Button btnRichiediFile;
        private System.Windows.Forms.TextBox txtRequestedFileName;
        private System.Windows.Forms.Button btnDisconnetti;
        private System.Windows.Forms.Button btnConnetti;
        private System.Windows.Forms.TextBox txtConnessione;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label lblInvia;
        private System.Windows.Forms.Label lblRichiesta;
        private System.Windows.Forms.Label lblVisualizz;
        private System.Windows.Forms.Button btnDeseleziona;
        private System.Windows.Forms.Button btnElimina;
        private System.Windows.Forms.Button btnDeseleziona2;
        private System.Windows.Forms.TextBox txtClient;
        private System.Windows.Forms.Label lblClient;
        private System.Windows.Forms.Button btnRefresh;
    }
}

